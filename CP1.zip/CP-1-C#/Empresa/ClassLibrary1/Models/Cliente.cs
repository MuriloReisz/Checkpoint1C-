﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models
{
    public class Cliente : Pessoa
    {
        private string telCliente;
        private string cep;

        //construtor convencional
        public Cliente()
        {
        }

        //construtor especializado
        public Cliente(string nome, string cpf, string telCliente, string cep)
            : base(nome, cpf)
        {
            this.telCliente = telCliente;
            this.cep = cep;
        }


        //getter and setter
        public string TelCliente
        {
            get { return telCliente; }
            set { telCliente = value; }
        }

        public string Cep
        {
            get { return cep; }
            set { cep = value; }
        }

        //método internal
        internal void DadosCliente()
        {
            Console.WriteLine("Telefone do Cliente: " + telCliente);
            Console.WriteLine("CEP do Cliente: " + cep);
        }
    }
}

