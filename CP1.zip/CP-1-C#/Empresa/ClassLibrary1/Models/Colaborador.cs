﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models
{
    public class Colaborador : Pessoa
    {
        private string telColaborador;
        private string cargo;

        //construtor convencional
        public Colaborador()
        {
        }

        //construtor especializado
        public Colaborador(string nome, string cpf, string telColaborador, string cargo)
            : base(nome, cpf)
        {
            this.telColaborador = telColaborador;
            this.cargo = cargo;
        }

        //getter and setter
        public string TelColaborador
        {
            get { return telColaborador; }
            set { telColaborador = value; }
        }

        public string Cargo
        {
            get { return cargo; }
            set { cargo = value; }
        }

        //método public
        public void DadosColaborador()
        {
            Console.WriteLine("Telefone do Colaborador: " + telColaborador);
            Console.WriteLine("Cargo do Colaborador: " + cargo);
        }

        //método override
        public override void Apresentar()
        {
            base.Apresentar();
            Console.WriteLine("Telefone do Colaborador: " + telColaborador);
            Console.WriteLine("Cargo do Colaborador: " + cargo);
        }
    }
}