﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models
{
    public class Empresa
    {
        private string nomeFantasia;
        private string razaoSocial;
        private string cnpj;


        // construtor convencional
        public Empresa()
        {
        }

        public Empresa(string nomeFantasia, string razaoSocial, string cnpj)
        {
            nomeFantasia = nomeFantasia;
            razaoSocial = razaoSocial;
            cnpj = cnpj;
        }

        //getter and setter
        public string NomeFantasia
        {
            get { return nomeFantasia; }
            set { nomeFantasia = value; }
        }
        public string RazaoSocial
        {
            get { return razaoSocial; }
            set { razaoSocial = value; }
        }
        public string Cnpj
        {
            get { return cnpj; }
            set { cnpj = value; }
        }

        //método virtual public
        public virtual void DadosEmpresa()
        {
            Console.WriteLine("Nome Fantasia: " + nomeFantasia);
            Console.WriteLine("Razão Social: " + razaoSocial);
            Console.WriteLine("CNPJ: " + cnpj);
        }
    }
}