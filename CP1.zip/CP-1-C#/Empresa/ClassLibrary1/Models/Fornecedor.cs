﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models
{
    public class Fornecedor : Empresa
    {
        private string representanteFornecedor;
        private string telFornecedor;

        //construtor convencional
        public Fornecedor()
        {
        }

        //construtor especializado
        public Fornecedor(string nomeFantasia, string razaoSocial, string cnpj, string representanteFornecedor, string telFornecedor)
            : base(nomeFantasia, razaoSocial, cnpj)
        {
            this.representanteFornecedor = representanteFornecedor;
            this.telFornecedor = telFornecedor;
        }

        //getter and setter
        public string RepresentanteFornecedor
        {
            get { return representanteFornecedor; }
            set { representanteFornecedor = value; }
        }
        public string TelFornecedor
        {
            get { return telFornecedor; }
            set { telFornecedor = value; }
        }

        //método public
        public void DadosFornecedor()
        {
            Console.WriteLine("Representante do Fornecedor: " + representanteFornecedor);
            Console.WriteLine("Telefone do Fornecedor: " + telFornecedor);
        }

        //método override
        public override void DadosEmpresa()
        {
            base.DadosEmpresa();
            Console.WriteLine("Representante do Fornecedor: " + representanteFornecedor);
            Console.WriteLine("Telefone do Fornecedor: " + telFornecedor);
        }
    }
}