﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Models
{
    public class Pessoa
    {
        private string nome;
        private string cpf;

        //construtor convencional
        public Pessoa()
        {
        }

        public Pessoa(string nome, string cpf)
        {
            nome = nome;
            cpf = cpf;
        }

        //getter and setter
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }

        //método protected
        protected void DadosPessoa()
        {
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("CPF: " + cpf);
        }

        //método virtual para ser acessado na classe colaborador pelo metodo override
        public virtual void Apresentar()
        {
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("CPF: " + cpf);
        }
    }
}