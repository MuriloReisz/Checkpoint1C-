﻿using System;
using System.Collections.Generic;
using ClassLibrary1.Models;

namespace ControleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            // Criar instâncias de cada classe
            Cliente cliente = new Cliente();
            cliente.Nome = "João";
            cliente.Cpf = "123.456.789-00";
            cliente.TelCliente = "(11) 98765-4321";
            cliente.Cep = "12345-678";

            Colaborador colaborador = new Colaborador();
            colaborador.Nome = "Maria";
            colaborador.Cpf = "987.654.321-00";
            colaborador.TelColaborador = "(11) 12345-6789";
            colaborador.Cargo = "Gerente";

            Empresa empresa = new Empresa();
            empresa.NomeFantasia = "Empresa X";
            empresa.RazaoSocial = "Razão Social X";
            empresa.Cnpj = "00.000.000/0000-00";

            Fornecedor fornecedor = new Fornecedor();
            fornecedor.NomeFantasia = "Fornecedor Y";
            fornecedor.RazaoSocial = "Razão Social Y";
            fornecedor.Cnpj = "11.111.111/1111-11";
            fornecedor.RepresentanteFornecedor = "Fulano";
            fornecedor.TelFornecedor = "(11) 55555-5555";


            // Executar método de cada classe
            Console.WriteLine("Testando métodos das classes:");

            Console.WriteLine("\nDados do Cliente:");
            cliente.DadosCliente();

            Console.WriteLine("\nDados do Colaborador:");
            colaborador.DadosColaborador();

            Console.WriteLine("\nDados da Empresa:");
            empresa.DadosEmpresa();

            Console.WriteLine("\nDados do Fornecedor:");
            fornecedor.DadosFornecedor();

            // Laço para exibir propriedades de uma lista de uma das classes
            List<Pessoa> pessoas = new List<Pessoa> { cliente, colaborador };
            Console.WriteLine("\nExibindo lista de pessoas:");
            foreach (var pessoa in pessoas)
            {
                Console.WriteLine($"Nome: {pessoa.Nome}, CPF: {pessoa.Cpf}");
            }

            // Controle de fluxo baseado em propriedade de uma classe
            Console.WriteLine("\nTomada de decisão baseada na propriedade Cargo do Colaborador:");
            if (colaborador.Cargo == "Gerente")
            {
                Console.WriteLine("O colaborador é um gerente.");
            }
            else
            {
                Console.WriteLine("O colaborador não é um gerente.");
            }
        }
    }
}